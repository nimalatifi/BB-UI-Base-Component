# BB-UI-Base-Component
This is a sample Base react component
