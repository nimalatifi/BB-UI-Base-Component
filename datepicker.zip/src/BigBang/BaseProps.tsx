
import {BaseDirection} from '../BigBang/BaseDirection'
export interface BaseProps {
    height?:string | number,
    width?:string | number,
    visible?:boolean,
    direction?:BaseDirection
 }