export enum BaseDirection {
    ltr="ltr",
    rtl="rtl"
}